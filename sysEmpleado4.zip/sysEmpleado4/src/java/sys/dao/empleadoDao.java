/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sys.dao;

import java.util.List;
import sys.model.Tbdepartamento;
import sys.model.Tbempleado;
import sys.model.Tbmunicipio;
import sys.model.Tbpais;

/**
 *
 * @author Juan Carlos Lopez
 */
public interface empleadoDao {
    
    //metodo para mostrar lista de empleados
    public List<Tbempleado> mostrarEmpleados();
    
    public void nuevoEmpleado (Tbempleado tbempleado);
    public void updateEmpleado (Tbempleado tbempleado);
    public void eliminarEmpleado (Tbempleado tbempleado);
    
    //Metodos para llenar dinamicamente los seleconemenus
    public List<Tbpais> listarPaises();
    public List<Tbdepartamento> listarDepartamentos(Tbempleado empleado);
    public List<Tbmunicipio> listarMunicipios(Tbempleado empleado);
    

}
